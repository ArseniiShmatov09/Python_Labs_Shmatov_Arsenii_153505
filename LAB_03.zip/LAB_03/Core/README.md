My Serializators for json&xml formats
